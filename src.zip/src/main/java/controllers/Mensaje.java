package controllers;

import javax.swing.JOptionPane;

public class Mensaje {
	static public void verMensaje(String mensaje) {
		JOptionPane.showMessageDialog(null, mensaje);
	}
}
